import styles from "../styles/Logada.module.css";
import Header from "../components/Header";
import Footer from "../components/Footer.jsx";
import Carrossel from "../components/Carrossel.jsx";

function UsuarioLogado() {
    return (
        <div>
            <Header />

            <h1>Olá, </h1>
            <button className={styles.botao} type="button">Editar </button>

            <img className={styles.sair} src="/logout.png" alt="Sair" />

            <div className={styles.ingressos}>
                 <h3>🎟️ Seus Ingressos</h3>

                <p>Você possui 2 ingressos</p>

                <button type="buttao">Ver Ingressos</button>
            </div>



            <div className={styles.agenda}>
                <h3>🗓️ Agendar Ingresso</h3>
                <br/>
                <button type="buttao">Ver Filmes</button>
            </div>



            <h2>Histórico de filme</h2>

            <div className={styles.linha}></div>

            <section className={styles.section}>
                <Carrossel id={5}/>




            </section>
            <Footer />
        </div>
    );
}

export default UsuarioLogado;