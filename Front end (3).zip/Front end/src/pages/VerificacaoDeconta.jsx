import styles from "../styles/VerificacaoDeconta.module.css"
import Header from "../components/Header";
import Footer from "../components/Footer.jsx";
import {Link} from "react-router-dom";

function VerificacaoDeconta() {

    return (
        <div>
            <Header />

            <h1 className={"styles.titulo"}>LUMINAFLIX</h1>

            <form>
                <label>Código de verificação</label>
                <input type={"number"} placeholder="Digite o código de verificação"/>
                <button type="submit">Entrar</button>
            </form>


            <Footer />
        </div>
    )
}

export default VerificacaoDeconta;