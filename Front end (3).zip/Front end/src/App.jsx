import { BrowserRouter, Routes, Route } from "react-router-dom";

import Home from "./pages/Home.jsx";
import Login from "./pages/Login.jsx";
import Cadastro from "./pages/Cadastro.jsx";
import Sucesso from "./pages/Sucesso.jsx";
import AlterarSenha from "./pages/AlterarSenha.jsx";
import Erro from "./pages/Erro.jsx";
import VerificacaoDeconta from "./pages/VerificacaoDeconta.jsx";
import Logada from "./pages/Logada.jsx";

function App() {

    return (
        <BrowserRouter>
            <Routes>

                <Route path="/" element={<Home />} />

                <Route path="/login" element={<Login />} />

                <Route path="/cadastro" element={<Cadastro />} />

                <Route path="/sucesso" element={<Sucesso />} />

                <Route path="/alterar-senha" element={<AlterarSenha />} />

                <Route path="/*" element={<Erro />} />

                <Route path="/verificacaodeconta" element={<VerificacaoDeconta />} />

                <Route path="/logada" element={<Logada />} />
            </Routes>
        </BrowserRouter>
    );
}

export default App;