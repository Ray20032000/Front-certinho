import styles from "../styles/Erro.module.css";
import Header from "../components/Header";
import Footer from "../components/Footer.jsx";
import { useNavigate } from "react-router-dom";

function Erro() {
    const navigate = useNavigate();




    return (
        <div>


        <Header />
        <div className={styles.container}>

            <h1>
                Ops! <br />
                Página não encontrada
            </h1>

            <h3 className={styles.subtitulo}>Erro 404</h3>

            <button className={styles.botao} onClick={() => navigate("/")}>
                Voltar para Home
            </button>


        </div>
    <Footer />
    </div>
    );
}

export default Erro;